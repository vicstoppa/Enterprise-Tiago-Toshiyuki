package br.com.fiap.jpa.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="T_ALUNO")
@SequenceGenerator(name="aluno",sequenceName="SQ_T_ALUNO",allocationSize=1)
public class Aluno implements Serializable {

	@Id
	@Column(name="cd_aluno")
	@GeneratedValue(generator="aluno", strategy=GenerationType.SEQUENCE)
	private int codigo;
	
	@Column(name="nm_aluno")
	private String nome;
	
	@Column(name="dt_matricula")
	private Calendar dataDatricula;
	
	@Column(name="st_bolsa")
	private boolean bolsista;

	@Column(name="vl_desconto")
	private int desconto;
	
	@Column
	private String turma;
	
	private float media;
	
	private Genero genero;
	
}
